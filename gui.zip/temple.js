//temple.js
var  $ = jQuery;

  $(document).ready(function(){
	$(".sub").hide();
	$(".gnb li").hover(function(){
		$(".sub", this).fadeIn(200);
	}, function(){
		$(".sub",this).fadeOut(200);
	
	});


  });//doc

  function myFunction() {
    var x = document.getElementById("myLinks");
    if (x.style.display === "block") {
        x.style.display = "none";
    } else {
        x.style.display = "block";
    }
}



