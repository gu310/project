//main.js


  $(document).ready(function(){
	$(".sub").hide();
	$(".gnb li").hover(function(){
		$(".sub", this).fadeIn(200);
	}, function(){
		$(".sub",this).fadeOut(200);
	
	});


  });//doc

  function myFunction() {
    var x = document.getElementById("myLinks");
    if (x.style.display === "block") {
        x.style.display = "none";
    } else {
        x.style.display = "block";
    }
}

var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}    
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 2000); // Change image every 2 seconds
}

$(document).ready(function(){
		
			count=$(".item").length;//개별 항목 갯수
		    wm=$(".container .item").width();//움직일 폭
            pg=0;//보이는 페이지 번호

			function mv(){
				$(".container").animate({"left":-wm*pg});
			};//function

			$(".next").click(function(){
              if (count-1>pg)
              {
                pg++;
				mv(); //함수호출
				
              };//if 

				
			});//next

		$(".prev").click(function(){
			if (pg>0)
			{
					pg--;
					mv();
			};//if
          });//prev
	});//doc


